<div class="jumbotron" style="background: #3b678e; color:#fff; margin-bottom:0px">
	<div class="container">
		<div class="container marketing">
			<div class="row">
				<div class="col-lg-3">
					<h2>Celke</h2>
					<p>Planos</p>
					<p>Recursos</p>
					<p>Blog</p>
					<p>Contato</p>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-3">
					<h2 style="color:#fff;">Política</h2>
					<p>Política de Privacidade</p>
					<p>Termos de Uso</p>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-3">
					<h2 style="color:#fff;">Contato</h2>
					<p>(41) 3503-6170</p>
					<p>Av. Republica Argentina, 5550 - Capão Raso CEP 81050-001 - Curitiba / PR</p>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-3">
					<h2 style="color:#fff;">Rede Sociais</h2>
					<p>Twiter</p>
					<p>Facebook</p>
					<p>Google +</p>
				</div><!-- /.col-lg-4 -->
			</div><!-- /.row -->
		</div>
	</div>
</div>