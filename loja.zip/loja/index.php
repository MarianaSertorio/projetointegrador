<?php
	define('pg','http://localhost/loja');
	include_once("adm/conexao/conexao.php")
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="Cesar Szpak - Celke">
		<link rel="icon" href="imagens/favicon.ico">
		<title>Celke</title>
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/jumbotron.css" rel="stylesheet">
	</head>
	<body role="document">
		<?php
			include_once("menu.php");
			
			$url = (isset($_GET['url'])) ? $_GET['url']:'';
			$explode = explode('/',$url);
			
			$paginas = array('home', 'contato', 'produtos', 'criacao_site', 'criacao_loja_virtual', 'gerenciador_estoque', 'recursos_vendas', 'recursos_estoque', 'recursos_caixa', 'recursos_orcamento', 'sobre_empresa');
			
			if(isset($explode[0])&& $explode[0] == ''){
				include "home.php";
			}elseif($explode[0]!=''){
				if(isset($explode[0]) && in_array($explode[0],$paginas)){
					include $explode[0].".php";
				}else{
					include "home.php";
				}
			}			
			
			include_once("rodape.php");
		?>
				
		<script src="js/jquery.min.js"></script>				
		<script src="js/bootstrap.min.js"></script>
	</body>
</html>