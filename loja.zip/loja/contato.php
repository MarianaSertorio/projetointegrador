<div class="container marketing">
	<div class="row featurette">
		
		<div class="col-md-6">
			<h3 class="featurette-heading">Contato por E-mail.</h3>
			<p class="lead">
			<form class="form-horizontal" method="POST" action="processa/proc_contato.php" enctype="multipart/form-data">
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Nome Completo*</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="inputEmail3" name="nome" placeholder="Preencher nome completo" required>
					</div>
				</div>
		  
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Email*</label>
					<div class="col-sm-10">
						<input type="email" class="form-control" id="inputEmail3" name="email" placeholder="Email" required>
					</div>
				</div>
			  
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Telefone*</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="inputEmail3" name="telefone" placeholder="Telefone" required>
					</div>
				</div>
			  
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Assunto*</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="inputEmail3" name="assunto" placeholder="Assunto da mensagem" required>
					</div>
				</div>
			  
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Mensagem*</label>
					<div class="col-sm-10">
						<textarea class="form-control" rows="3" name="mensagem"></textarea>
					</div>
				</div>
		  
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<button type="submit" class="btn btn-success">Enviar</button>
					</div>
				</div>
			</form></p>
		</div>
		<div class="col-md-6">
			<h2 class="featurette-heading">Endereço</h2>
			<p class="lead">
				<address>
					<strong>Celke.</strong><br>
					Av. Republica Argentina, 5550 - Capão Raso<br>
					CEP 81050-001 - Curitiba / PR<br>
					<abbr title="Phone">P:</abbr> (41) 3503-6170
				</address>
				<address>
					<strong>Cesar</strong><br>
					<a href="mailto:#">cesart@celke.com.br</a>
				</address>
			</p>
		</div>
	</div>
</div>
