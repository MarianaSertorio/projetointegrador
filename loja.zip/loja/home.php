<?php
	$result_carousels = "SELECT * FROM carousels ORDER BY ordem asc LIMIT 3";
	$resultado_carousels = mysqli_query($conn , $result_carousels);
?>
<!-- Carousel
================================================== -->
<div id="myCarousel" class="carousel slide" data-ride="carousel">
	<!-- Indicators -->
	<ol class="carousel-indicators">
		<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
		<li data-target="#myCarousel" data-slide-to="1"></li>
		<li data-target="#myCarousel" data-slide-to="2"></li>
	</ol>
	<div class="carousel-inner" role="listbox">
		<?php 
		$controle_slide_um = 1;
		while($row_carousels = mysqli_fetch_assoc($resultado_carousels)){?>
			<div class="item <?php if($controle_slide_um == '1'){ echo 'active'; $controle_slide_um = 2;} ?>">
				<img class="first-slide" src="imagemcarousel/<?php echo $row_carousels["imagem"]; ?>" alt="<?php echo $row_carousels["nome"]; ?>">
				<div class="container">
					<div class="carousel-caption">
						<p><a class="btn btn-lg btn-primary" href="<?php echo $row_carousels["url"]; ?>" role="button">Ver mais</a></p>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
	<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
		<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	</a>
	<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
		<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	</a>
</div><!-- /.carousel -->

<div class="container marketing text-center">
		<h1 class="text-center" style="margin-bottom:50px;"> O que sua empresa precisa?</h1>
	<div class="row">
		<div class="col-lg-4">
			<a href="criacao_site.html"><img class="img-circle" src="imagens/como-montar-blog.png" alt="Generic placeholder image" width="140" height="140"></a>
			<h2>Site</h2>
		</div><!-- /.col-lg-4 -->
		<div class="col-lg-4">
			<a href="criacao_loja_virtual.html"><img class="img-circle" src="imagens/como-criar-loja-virtual.png" alt="Generic placeholder image" width="140" height="140"></a>
			<h2>Loja virtual</h2>
		</div><!-- /.col-lg-4 -->
		<div class="col-lg-4">
			<a href="gerenciador_estoque.html"><img class="img-circle" src="imagens/gerenciador-de-estoque.png" alt="Generic placeholder image" width="140" height="140"></a>
			<h2>Gerenciador de Estoque</h2>
		</div><!-- /.col-lg-4 -->
	</div><!-- /.row -->
</div>
<div class="jumbotron" style="background: #3b678e; margin-top: 50px;">
	<div class="container text-center">
		<h2 class="text-center" style="margin-bottom:70px; color:#fff;">Recursos</h2>
		<div class="container marketing">
			<div class="row">
				<div class="col-lg-3">
					<a href="recursos_vendas.html"><img class="img-circle" src="imagens/carrinho_circulo-sem-fundo.png" alt="Generic placeholder image" width="140" height="140"></a>
					<h2 style="color:#fff;">Vendas</h2>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-3">
					<a href="recursos_estoque.html"><img class="img-circle" src="imagens/estoque-circulo-sem-fundo.png" alt="Generic placeholder image" width="140" height="140"></a>
					<h2 style="color:#fff;">Estoque</h2>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-3">
					<a href="recursos_caixa.html"><img class="img-circle" src="imagens/calculadora_circulo_sem_fundo.png" alt="Generic placeholder image" width="140" height="140"></a>
					<h2 style="color:#fff;">Caixa</h2>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-3">
					<a href="recursos_orcamento.html"><img class="img-circle" src="imagens/cifrao-circulo-sem-fundo.png" alt="Generic placeholder image" width="140" height="140"></a>
					<h2 style="color:#fff;">Orçamento</h2>
				</div><!-- /.col-lg-4 -->
			</div><!-- /.row -->
		</div>
	</div>
</div>

<div class="jumbotron" style="background: #fff; margin-top: 50px;">
	<div class="container text-center">
		<h2 class="text-center" style="color:#666565;">Depoimentos de quem usa.</h2>
	</div><!-- /.row -->
</div>
		
<!-- Carousel
================================================== -->
<div id="myCarousel" class="carousel slide" data-ride="carousel" style="height: 200px;">
	<div class="carousel-inner" role="listbox">
		<div class="item active" style="height: 200px;">
			<div class="container">
				<div class="carousel-caption">
					<h2>Carlos Silva.</h2>
					<p>O empenho em analisar o comprometimento entre as equipes oferece uma oportunidade para verificação dos níveis de motivação departamental.</p>
				</div>
			</div>
		</div>
		<div class="item" style="height: 200px;">
			<div class="container">
				<div class="carousel-caption">
					<h2>José Antunes.</h2>
					<p>O cuidado em identificar pontos críticos na percepção das dificuldades deve passar por modificações independentemente de alternativas às soluções ortodoxas.</p>
				</div>
			</div>
		</div>
		<div class="item" style="height: 200px;">
			<div class="container">
				<div class="carousel-caption">
					<h2>Maria Silva.</h2>
					<p>A nível organizacional, a constante divulgação das informações facilita a criação dos métodos utilizados na avaliação de resultados. Neste sentido, a consolidação das estruturas exige a precisão e a definição das formas de ação.</p>
				</div>
			</div>
		</div>
	</div>
</div><!-- /.carousel -->