<?php
	include_once("../adm/conexao/conexao.php");
	$nome = mysqli_real_escape_string($conn, $_POST['nome']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$telefone = mysqli_real_escape_string($conn, $_POST['telefone']);
	$assunto = mysqli_real_escape_string($conn, $_POST['assunto']);
	$mensagem = mysqli_real_escape_string($conn, $_POST['mensagem']);
	
	$result_usuario = "INSERT INTO contatos (nome, email, telefone, assunto, mensagem, situacos_contato_id, created) VALUES ('$nome', '$email', '$telefone', '$assunto', '$mensagem', '1', NOW())";
	$resultado_usuario = mysqli_query($conn, $result_usuario);	
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
	</head>

	<body> <?php
		if(mysqli_affected_rows($conn) != 0){
			echo "
				<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=http://localhost/loja/index.html'>
				<script type=\"text/javascript\">
					alert(\"Mensagem cadastrada com Sucesso.\");
				</script>
			";	
		}else{
			echo "
				<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=http://localhost/loja/index.html'>
				<script type=\"text/javascript\">
					alert(\"Mensagem não foi cadastrada com Sucesso.\");
				</script>
			";	
		}?>
	</body>
</html>
<?php $conn->close(); ?>