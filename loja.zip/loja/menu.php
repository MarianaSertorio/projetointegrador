<!-- Fixed navbar -->
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="<?php echo pg.'/index'; ?>">Celke</a>
		</div>
		<div id="navbar" class="navbar-collapse collapse">
			<ul class="nav navbar-nav">
				<li><a href="<?php echo pg.'/index'; ?>">Home</a></li>
				<li class="dropdown">
					<a href="<?php echo pg.'/produtos'; ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Produtos <span class="caret"></span></a>
					<ul class="dropdown-menu">
						<li><a href="<?php echo pg.'/criacao_site'; ?>">Site</a></li>
						<li><a href="<?php echo pg.'/criacao_loja_virtual'; ?>">Loja Virtual</a></li>
						<li><a href="<?php echo pg.'/gerenciador_estoque'; ?>">Gerenciador de Estoque</a></li>
						<li role="separator" class="divider"></li>
						<li class="dropdown-header">Recursos</li>
						<li><a href="<?php echo pg.'/recursos_vendas'; ?>">Vendas</a></li>
						<li><a href="<?php echo pg.'/recursos_estoque'; ?>">Estoque</a></li>
						<li><a href="<?php echo pg.'/recursos_caixa'; ?>">Caixa</a></li>
						<li><a href="<?php echo pg.'/recursos_orcamento'; ?>">Orçamento</a></li>
					</ul>
				</li>
				<li><a href="<?php echo pg.'/sobre_empresa'; ?>">Sobre a Empresa</a></li>
				<li><a href="<?php echo pg.'/contato'; ?>">Contato</a></li>
				
			</ul>
		</div><!--/.nav-collapse -->
	</div>
</nav>