<?php
	$id = $_GET['id'];
	//Buscar os dados referente ao usuario situado neste id
	$result_carousels = "SELECT * FROM carousels WHERE id = '$id' LIMIT 1";
	$resultado_carousels = mysqli_query($conn, $result_carousels);
	$row_carousels = mysqli_fetch_assoc($resultado_carousels);	
?>
<div class="container theme-showcase" role="main">
	<div class="page-header">
        <h1>Visualizar Usuário</h1>
	</div>
	<div class="row">
		<div class="pull-right" style="padding-bottom: 20px; ">
			<a href="administrativo.php?link=18">
				<button type='button' class='btn btn-sm btn-success'>Listar</button>
			</a>
			
			<a href="administrativo.php?link=8&id=<?php echo $row_carousels["id"]; ?>">
				<button type="button" class="btn btn-sm btn-warning">
					Editar
				</button>
			</a>
			
			<a href="administrativo/processa/adm_apagar_carousel.php?id=<?php echo $row_carousels["id"]; ?>">
				<button type="button" class="btn btn-sm btn-danger">
					Apagar
				</button>
			</a>
		</div>
	</div>
	<dl class="dl-horizontal">	
		<dt>Id: </dt>
		<dd><?php echo $row_carousels['id']; ?></dd>
		<dt>Nome: </dt>
		<dd><?php echo $row_carousels['nome']; ?></dd>
		<dt>URL: </dt>
		<dd><?php echo $row_carousels['url']; ?></dd>
		<dt>Imagem: </dt>
		<dd>
			<img src="../imagemcarousel/<?php echo $row_carousels['imagem']; ?>" height="100" width="320">
		</dd>
		<dt>Ordem: </dt>
		<dd><?php echo $row_carousels['ordem']; ?></dd>
		<dt>Inserido: </dt>
		<dd><?php 
			if(isset($row_carousels['created'])){
				$inserido = $row_carousels['created'];
				echo date('d/m/Y H:i:s', strtotime($inserido)); 
			}?>
		</dd>
		<dt>Alterado: </dt>
		<dd><?php 
			if(isset($row_carousels['modified'])){				
				echo date('d/m/Y H:i:s',strtotime($row_carousels['modified'])); 
			} ?>
		</dd>
	</dl>
</div>