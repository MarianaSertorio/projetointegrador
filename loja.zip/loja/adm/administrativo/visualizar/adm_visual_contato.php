<?php
	$id = $_GET['id'];
	//Buscar os dados referente ao usuario situado neste id
	$result_contatos = "SELECT * FROM contatos WHERE id = '$id' LIMIT 1";
	$resultado_contatos = mysqli_query($conn, $result_contatos);
	$row_contatos = mysqli_fetch_assoc($resultado_contatos);
	
	//Alterar situação da mensagem
	if($row_contatos['situacos_contato_id'] == '1'){
		$result_contatos = "UPDATE contatos SET situacos_contato_id = '2' WHERE id = '$id'";
		$result_contatos = mysqli_query($conn, $result_contatos);
	}
?>
<div class="container theme-showcase" role="main">
	<div class="page-header">
        <h1>Visualizar Mensagem</h1>
	</div>
	<div class="row">
		<div class="pull-right" style="padding-bottom: 20px; ">
			<a href="administrativo.php?link=14">
				<button type='button' class='btn btn-sm btn-success'>Listar</button>
			</a>
			
			<a href="administrativo.php?link=16&id=<?php echo $row_contatos["id"]; ?>">
				<button type="button" class="btn btn-sm btn-warning">
					Editar
				</button>
			</a>
			
			<a href="administrativo/processa/adm_apagar_contato.php?id=<?php echo $row_contatos["id"]; ?>">
				<button type="button" class="btn btn-sm btn-danger">
					Apagar
				</button>
			</a>
		</div>
	</div>
	<dl class="dl-horizontal">	
		<dt>Id: </dt>
		<dd><?php echo $row_contatos['id']; ?></dd>
		<dt>Nome: </dt>
		<dd><?php echo $row_contatos['nome']; ?></dd>
		<dt>E-mail: </dt>
		<dd><?php echo $row_contatos['email']; ?></dd>
		<dt>Telefone: </dt>
		<dd><?php echo $row_contatos['telefone']; ?></dd>
		<dt>Assunto: </dt>
		<dd><?php echo $row_contatos['assunto']; ?></dd>
		<dt>Mensagem: </dt>
		<dd><?php echo $row_contatos['mensagem']; ?></dd>
		<dt>Situação da Mensagem: </dt>
		<dd>
			<?php 
				$situacos_contato = $row_contatos['situacos_contato_id'];
				$result_situacos_contato = "SELECT * FROM situacos_contatos WHERE id = '$situacos_contato'";
				$result_situacos_contato = mysqli_query($conn, $result_situacos_contato);
				$row_situacos_contato = mysqli_fetch_assoc($result_situacos_contato); ?>				
				<span class="label label-<?php echo $row_situacos_contato['cor']; ?>"><?php echo $row_situacos_contato['nome']; ?></span>
		</dd>
		<dt>Inserido: </dt>
		<dd><?php 
			if(isset($row_contatos['created'])){
				$inserido = $row_contatos['created'];
				echo date('d/m/Y H:i:s', strtotime($inserido)); 
			}?>
		</dd>
		<dt>Alterado: </dt>
		<dd><?php 
			if(isset($row_contatos['modified'])){				
				echo date('d/m/Y H:i:s',strtotime($row_contatos['modified'])); 
			} ?>
		</dd>
		<form method="POST" action="administrativo/processa/adm_proc_edita_situa_contato.php">
			<dt>Alterar Situação: </dt>
			<dd>
				
					<label class="radio-inline">
						<input type="radio" name="situacos_contatos" id="inlineRadio1" value="1" 
							<?php if($row_contatos['situacos_contato_id'] == 1){
								echo 'checked';
							} ?>
							> <span class="label label-danger">Pendente</span>
					</label>
					<label class="radio-inline">
						<input type="radio" name="situacos_contatos" id="inlineRadio2" value="2"
							<?php if($row_contatos['situacos_contato_id'] == 2){
								echo 'checked';
							} ?>
							> <span class="label label-info">Visualizado</span>
					</label>
					<label class="radio-inline">
						<input type="radio" name="situacos_contatos" id="inlineRadio3" value="3"
							<?php if($row_contatos['situacos_contato_id'] == 3){
								echo 'checked';
							} ?>
							> <span class="label label-success">Resolvido</span>
					</label>				
				
			</dd>		
			<dt style="margin-top: 20px;"></dt>
			<dd style="margin-top: 20px;">
				<input type="hidden" name="id" value="<?php echo $id; ?>">
				<button type="submit" class="btn btn-xs btn-warning">Confirmar alteração</button>
			</dd>
		</form>
	</dl>
</div>