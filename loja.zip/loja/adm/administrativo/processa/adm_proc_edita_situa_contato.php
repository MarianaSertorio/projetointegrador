<?php
	include_once("../../conexao/conexao.php");
	$id = mysqli_real_escape_string($conn, $_POST['id']);
	if(isset($_POST['situacos_contatos'])){		
		$situacos_contatos = mysqli_real_escape_string($conn, $_POST['situacos_contatos']);
		
		$result_contatos = "UPDATE contatos SET situacos_contato_id='$situacos_contatos', modified =  NOW() WHERE id = '$id'";	
		$resultado_contatos = mysqli_query($conn, $result_contatos);
	}
		
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
	</head>

	<body> <?php
		if(mysqli_affected_rows($conn) != 0){
			echo "
				<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=http://localhost/loja/adm/administrativo.php?link=17&id=$id'>
				<script type=\"text/javascript\">
					alert(\"Situação da mensagem alterada com Sucesso.\");
				</script>
			";	
		}else{
			echo "
				<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=http://localhost/loja/adm/administrativo.php?link=17&id=$id'>
				<script type=\"text/javascript\">
					alert(\"Situação da mensagem não foi alterada com Sucesso.\");
				</script>
			";	
		}?>
	</body>
</html>
<?php $conn->close(); ?>