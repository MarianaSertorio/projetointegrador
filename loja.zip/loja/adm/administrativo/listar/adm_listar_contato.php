<?php
	$result_contatos = "SELECT * FROM contatos";
	$resultado_contatos = mysqli_query($conn , $result_contatos);
?>
<div class="container theme-showcase" role="main">
	<div class="page-header">
        <h1>Lista de Mensagens</h1>
	</div>
	<div class="row espaco">
		<div class="pull-right">
			<a href="administrativo.php?link=15"><button type='button' class='btn btn-sm btn-success'>Cadastrar</button></a>
		</div>
	</div>
	<div class="row">
        <div class="col-md-12">
			<table class="table">
				<thead>
					<tr>
						<th class="text-center">Id</th>
						<th class="text-center">Nome</th>
						<th class="text-center">Assunto</th>
						<th class="text-center">Inserido</th>
						<th class="text-center">Ação</th>
					</tr>
				</thead>
				<tbody>
					<?php while($row_contatos = mysqli_fetch_assoc($resultado_contatos)){
						$situacos_contatos = $row_contatos["situacos_contato_id"]; 
						$result_situacos_contatos = "SELECT * FROM situacos_contatos WHERE id = '$situacos_contatos' LIMIT 1";
						$resultado_situacos_contatos = mysqli_query($conn, $result_situacos_contatos);
						$row_situacos_contatos = mysqli_fetch_assoc($resultado_situacos_contatos);
						?>
						<tr class="<?php echo $row_situacos_contatos["cor"]; ?>">
							<td class="text-center"><?php echo $row_contatos["id"]; ?></td>
							<td class="text-center"><?php echo $row_contatos["nome"]; ?></td>
							<td class="text-center"><?php echo $row_contatos["assunto"]; ?></td>
							<td class="text-center"><?php echo date('d/m/Y H:i:s',strtotime($row_contatos["created"])); ?></td>
							<td class="text-center">
								<a href="administrativo.php?link=17&id=<?php echo $row_contatos["id"]; ?>">
									<button type="button" class="btn btn-xs btn-primary">
										Visualizar
									</button>
								</a>
								<a href="administrativo.php?link=16&id=<?php echo $row_contatos["id"]; ?>">
									<button type="button" class="btn btn-xs btn-warning">
										Editar
									</button>
								</a>
								<a href="administrativo/processa/adm_apagar_contato.php?id=<?php echo $row_contatos["id"]; ?>">
									<button type="button" class="btn btn-xs btn-danger">
										Apagar
									</button>
								</a>
							</td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
        </div>
	</div>
</div>