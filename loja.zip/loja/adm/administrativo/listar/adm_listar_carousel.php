<?php
	$result_carousels = "SELECT * FROM carousels ORDER BY ordem asc";
	$resultado_carousels = mysqli_query($conn , $result_carousels);
	
	$contr_sob = mysqli_num_rows($resultado_carousels);
	
?>
<div class="container theme-showcase" role="main">
	<div class="page-header">
        <h1>Lista de Carousel</h1>
	</div>
	<div class="row espaco">
		<div class="pull-right">
			<a href="administrativo.php?link=19"><button type='button' class='btn btn-sm btn-success'>Cadastrar</button></a>
		</div>
	</div>
	<div class="row">
        <div class="col-md-12">
			<table class="table">
				<thead>
					<tr>
						<th class="text-center">Id</th>
						<th class="text-center">Nome</th>
						<th class="text-center">URL</th>
						<th class="text-center">Ordem</th>
						<th class="text-center">Inserido</th>
						<th class="text-center">Ação</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$contr_ord = 1;
					while($row_carousels = mysqli_fetch_array($resultado_carousels)){
						$carousel_id = $row_carousels["id"];
							
						?>
						<tr>
							<td class="text-center"><?php echo $row_carousels["id"]; ?></td>
							<td class="text-center"><?php echo $row_carousels["nome"]; ?></td>
							<td class="text-center"><?php echo $row_carousels["url"]; ?></td>
							<td class="text-center"><?php echo $row_carousels["ordem"]; ?></td>
							<td class="text-center"><?php echo date('d/m/Y H:i:s',strtotime($row_carousels["created"])); ?></td>
							<td class="text-center">
								<?php
								if($contr_sob != $contr_ord){?>
									<a href='administrativo/processa/proc_edit_ordem_carousel.php?situacao=1&id=<?php echo $carousel_id; ?>'><button type='button' class='btn btn-xs btn-primary'><span class="glyphicon glyphicon-arrow-down" aria-hidden="true"></span></button></a>
								<?php }else { ?>
									<a href='#'><button type='button' class='btn btn-xs btn-primary'><span class="glyphicon glyphicon-arrow-down" aria-hidden="true"></span></button></a>
								<?php } ?>
								<?php if($contr_ord != 1){?>
								<a href='administrativo/processa/proc_edit_ordem_carousel.php?situacao=2&id=<?php echo $carousel_id; ?>'><button type='button' class='btn btn-xs btn-primary'><span class="glyphicon glyphicon-arrow-up" aria-hidden="true"></span></button></a>		
								<?php }else{ ?>	
									<a href='#'><button type='button' class='btn btn-xs btn-primary'><span class="glyphicon glyphicon-arrow-up" aria-hidden="true"></span></button></a>
								<?php } ?>	
								<a href="administrativo.php?link=21&id=<?php echo $row_carousels["id"]; ?>">
									<button type="button" class="btn btn-xs btn-primary">
										Visualizar
									</button>
								</a>
								<a href="administrativo/processa/adm_apagar_carousel.php?id=<?php echo $row_carousels["id"]; ?>">
									<button type="button" class="btn btn-xs btn-danger">
										Apagar
									</button>
								</a>
							</td>
						</tr>
					<?php
						$contr_ord = $contr_ord + 1; 					
					} ?>
				</tbody>
			</table>
        </div>
	</div>
</div>